<?php

return [
    'name' => 'Recruitment'
];
