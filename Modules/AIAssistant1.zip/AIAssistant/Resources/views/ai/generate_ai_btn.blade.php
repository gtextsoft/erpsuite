<a  class="btn btn-primary text-white btn-sm" data-size="lg" data-ajax-popup-over="true" data-url="{{ route('aiassistant.generate',[$template_module,$module]) }}" data-bs-toggle="tooltip" data-bs-placement="top" title="{{ __('Generate') }}" data-title="{{ __('Generate Content With AI') }}">
    <i class="fas fa-robot"></i> {{ __('Generate with AI') }}
</a>
