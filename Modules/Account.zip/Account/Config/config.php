<?php

return [
    'name' => 'Account'
];
