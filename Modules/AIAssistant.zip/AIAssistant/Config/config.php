<?php

return [
    'name' => 'AIAssistant'
];
