<?php

return [
    'name' => 'DoubleEntry'
];
